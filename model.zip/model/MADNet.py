import torch
import torch.nn as nn
import torch.nn.functional as F

from model.Attention.CBAM import CBAMBlock
from model.Attention.CGA import CGAFusion
from model.Attention.ECA import ECAAttention
from model.Attention.EMA import EMA
from model.Attention.SE import SEAttention
from model.CONV.DOconv import DOConv2d
from model.CONV.RFAConv import RFAConv1, RFCBAMConv, RFCAConv
from model.CONV.RepConv import RepConv
from model.CONV.dyconv import Dynamic_conv2d
from model.DEblock import DEABlockTrain
from model.incept import InceptionA, InceptionB
from model.untils import ASPP, _DenseASPPBlock
from model.Dysample import DySample
from model.CONV.ODconv import ODConv2d
from model.Attention.Biformer import BiLevelRoutingAttention_nchw



class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        """(convolution => [BN] => ReLU) * 2"""
        super().__init__()

        self.conv11 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),

            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv11(x)

# 尝试替换down中的双卷积
class RFADoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        """(RFAConvolution => [BN] => ReLU) * 2"""
        super().__init__()

        self.rfacnn11 = nn.Sequential(
            RFAConv1(in_channels, out_channels, kernel_size=3,stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),

            RFAConv1(out_channels, out_channels, kernel_size=3,stride=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.rfacnn11(x)

class Down(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.maxpool_conv = nn.Sequential(
            nn.MaxPool2d(2),

            RFADoubleConv(in_channels, out_channels),
            EMA(out_channels)
        )

    def forward(self, x):
        return self.maxpool_conv(x)




class Up(nn.Module):
    def __init__(self, in_channels, out_channels, bilinear=True):
        super().__init__()

        if bilinear:
            # self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
            self.up = DySample(in_channels // 2, scale=2)

        else:
            self.up = nn.ConvTranspose2d(in_channels // 2, in_channels // 2, kernel_size=2, stride=2)

        self.conv = DoubleConv(in_channels, out_channels)



    def forward(self, x1, x2):
        x1 = self.up(x1)

        # Adjust the shape of the tensors
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]
        x1 = F.pad(x1, (diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2))

        x = torch.cat([x2, x1], dim=1)


        return self.conv(x)



class UNet(nn.Module):
    def __init__(self, input_classes, input_channels=6, bilinear=True):
        super().__init__()

        self.input_classes = input_classes
        self.input_channels = input_channels
        self.bilinear = bilinear

        self.inc = DoubleConv(input_channels, 32)#
        self.down1 = Down(32, 64)
        self.down2 = Down(64, 128)
        self.down3 = Down(128, 256)
        self.down4 = Down(256, 256)
        # Add ASPP module after the last downsampling layer
        self.aspp = ASPP(256, 256)


        self.up1 = Up(512, 128, bilinear)
        self.up2 = Up(256, 64, bilinear)
        self.up3 = Up(128, 32, bilinear)
        self.up4 = Up(64, 32, bilinear)



        self.outc = nn.Conv2d(32, input_classes, kernel_size=1)

    def forward(self, xA, xB):

        x = torch.concat([xA, xB], dim=1)
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        # print("After x5 shape:", x5.shape)
        # Add ASPP module

        x5 = self.aspp(x5)

        x6 = self.up1(x5, x4)
        x7 = self.up2(x6, x3)
        x8 = self.up3(x7, x2)
        x9 = self.up4(x8, x1)
        out = self.outc(x9)
        return out


if __name__ == "__main__":
    xA = torch.randn(4, 3, 128, 128).cuda()
    xB = torch.randn(4, 3, 128, 128).cuda()
    model1 = UNet(input_classes=2, input_channels=6).cuda()
    output1 = model1(xA, xB).cuda()
    print(output1.size())
    from thop import profile
    from thop import clever_format
    dummy_input = torch.randn(4, 3, 128, 128).cuda()
    flops, params = profile(model1, (dummy_input, dummy_input))
    flops, params = clever_format([flops, params], '%.3f')
    print('flops: ', flops, 'params: ', params)


